package com.zensar.demo.model;

import java.util.List;

public class UserRequest {
	
 private List<User> userList;

public List<User> getUserList() {
	return userList;
}

public void setUserList(List<User> userList) {
	this.userList = userList;
}
 

}
